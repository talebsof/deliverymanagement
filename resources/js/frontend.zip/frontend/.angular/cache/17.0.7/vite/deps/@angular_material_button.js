import {
  MAT_FAB_DEFAULT_OPTIONS,
  MAT_FAB_DEFAULT_OPTIONS_FACTORY,
  MatAnchor,
  MatButton,
  MatButtonModule,
  MatFabAnchor,
  MatFabButton,
  MatIconAnchor,
  MatIconButton,
  MatMiniFabAnchor,
  MatMiniFabButton
} from "./chunk-JOEZENBD.js";
import "./chunk-UZYN2T4I.js";
import "./chunk-DENEZ3FO.js";
import "./chunk-DAI7SMJO.js";
import "./chunk-NDJFLRQQ.js";
import "./chunk-4PGRSMHT.js";
import "./chunk-45R4DEQH.js";
import "./chunk-V4QF72PL.js";
export {
  MAT_FAB_DEFAULT_OPTIONS,
  MAT_FAB_DEFAULT_OPTIONS_FACTORY,
  MatAnchor,
  MatButton,
  MatButtonModule,
  MatFabAnchor,
  MatFabButton,
  MatIconAnchor,
  MatIconButton,
  MatMiniFabAnchor,
  MatMiniFabButton
};
//# sourceMappingURL=@angular_material_button.js.map
