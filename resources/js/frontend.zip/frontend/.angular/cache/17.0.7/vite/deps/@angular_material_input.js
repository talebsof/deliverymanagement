import {
  MAT_INPUT_VALUE_ACCESSOR,
  MatInput,
  MatInputModule,
  getMatInputUnsupportedTypeError
} from "./chunk-HKP2QINO.js";
import "./chunk-C7XWTSE2.js";
import "./chunk-4KOTJIMF.js";
import "./chunk-UZYN2T4I.js";
import "./chunk-DENEZ3FO.js";
import "./chunk-DAI7SMJO.js";
import "./chunk-NDJFLRQQ.js";
import "./chunk-4PGRSMHT.js";
import "./chunk-45R4DEQH.js";
import "./chunk-V4QF72PL.js";
export {
  MAT_INPUT_VALUE_ACCESSOR,
  MatInput,
  MatInputModule,
  getMatInputUnsupportedTypeError
};
//# sourceMappingURL=@angular_material_input.js.map
