import {
  BrowserAnimationsModule,
  InjectableAnimationEngine,
  NoopAnimationsModule,
  provideAnimations,
  provideNoopAnimations
} from "./chunk-DENEZ3FO.js";
import "./chunk-DAI7SMJO.js";
import "./chunk-NDJFLRQQ.js";
import "./chunk-4PGRSMHT.js";
import {
  ANIMATION_MODULE_TYPE
} from "./chunk-45R4DEQH.js";
import "./chunk-V4QF72PL.js";
export {
  ANIMATION_MODULE_TYPE,
  BrowserAnimationsModule,
  NoopAnimationsModule,
  provideAnimations,
  provideNoopAnimations,
  InjectableAnimationEngine as ɵInjectableAnimationEngine
};
//# sourceMappingURL=@angular_platform-browser_animations.js.map
